Minetest Game mod: sethome
==========================
See license.txt for license information.

Authors of source code
----------------------
sfan5 (MIT)
