Minetest Game mod: dungeon_loot
===============================
Adds randomly generated chests with some "loot" to generated dungeons,
an API to register additional loot is provided.
Only works if dungeons are actually enabled in mapgen flags.

License information can be found in license.txt

Authors of source code
----------------------
Originally by sfan5 (MIT)
